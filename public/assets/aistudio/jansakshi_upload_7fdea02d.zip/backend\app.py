
from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import uuid
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Database location
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "jansakshi.db")


# ---------- DATABASE CONNECTION ----------

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_database():
    conn = get_db_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS complaints (
            id TEXT PRIMARY KEY,
            description TEXT NOT NULL,
            category TEXT,
            location TEXT,
            latitude REAL,
            longitude REAL,
            image_path TEXT,
            ai_summary TEXT,
            ai_priority TEXT,
            status TEXT DEFAULT 'Submitted',
            created_at TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


# ---------- HOME & HEALTH ----------

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "project": "JanSakshi AI",
        "message": "Backend is running!",
        "status": "success"
    })


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "backend": "online",
        "database": "connected"
    })


# ---------- REGISTER COMPLAINT ----------

@app.route("/api/complaints", methods=["POST"])
def register_complaint():

    data = request.get_json(silent=True) or {}

    description = data.get("description", "").strip()

    if not description:
        return jsonify({
            "error": "Complaint description is required"
        }), 400

    complaint_id = "JS-" + uuid.uuid4().hex[:8].upper()
    created_at = datetime.now().isoformat(timespec="seconds")

    conn = get_db_connection()

    conn.execute("""
        INSERT INTO complaints (
            id, description, category, location,
            latitude, longitude, image_path,
            ai_summary, ai_priority, status, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        complaint_id,
        description,
        data.get("category"),
        data.get("location"),
        data.get("latitude"),
        data.get("longitude"),
        data.get("image_path"),
        None,
        None,
        "Submitted",
        created_at
    ))

    conn.commit()
    conn.close()

    return jsonify({
        "message": "Complaint registered successfully",
        "complaint_id": complaint_id,
        "status": "Submitted"
    }), 201


# ---------- GET ALL COMPLAINTS ----------

@app.route("/api/complaints", methods=["GET"])
def get_complaints():

    conn = get_db_connection()

    rows = conn.execute("""
        SELECT * FROM complaints
        ORDER BY created_at DESC
    """).fetchall()

    conn.close()

    return jsonify([dict(row) for row in rows])


# ---------- TRACK ONE COMPLAINT ----------

@app.route("/api/complaints/<complaint_id>", methods=["GET"])
def get_complaint(complaint_id):

    conn = get_db_connection()

    row = conn.execute("""
        SELECT * FROM complaints WHERE id = ?
    """, (complaint_id,)).fetchone()

    conn.close()

    if row is None:
        return jsonify({
            "error": "Complaint not found"
        }), 404

    return jsonify(dict(row))


# ---------- START SERVER ----------

if __name__ == "__main__":

    initialize_database()

    print("Starting JanSakshi AI backend...")

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )
